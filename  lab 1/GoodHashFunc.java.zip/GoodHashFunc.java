package lab01.student;

import java.util.ArrayList;

public class GoodHashFunc {
    public static int computeHash(String input){
        //ArrayList<Integer> h = new ArrayList<Integer>();
        int []cool = new int[input.length()];
        for (int i = 0; i < input.length(); i++ ) {
            int num = input.charAt(i);
            int hash = (int)Math.pow(31,input.length() - (i+1));
            int newNum = num * hash;
            //h.add(hash);
            cool[i] = newNum;
        }
        int hashcode = 0;//new int[h.length];
        for (int i = 0; i < cool.length ; i++) {
            hashcode += cool[i];


        }
        return hashcode;


    }
    public static void main(String[] args){
        // create a new scanner to read from the command line
        java.util.Scanner scanner = new java.util.Scanner(System.in);

        // prompt the user to enter a string
        System.out.println("Please enter a string of text: ");
        // read everything that the user types up to the end of the line
        String line = scanner.nextLine();
        System.out.println("The computed hash for the specified string is:" + " " + computeHash(line));


        // ALWAYS close your scanner
        scanner.close();
    }

}
