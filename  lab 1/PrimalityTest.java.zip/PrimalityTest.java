package lab01.student;

public class PrimalityTest {
    public static boolean isPrime(int number){
        if (number == 0){
            return false;
        }
        if (number == 1){
            System.out.println(number + " " + "is not prime!");
            return false;
        }
        if (number == 2){
            System.out.println(number + " " + "is prime!");
            return true;
        }
        if (number == 4) {
            System.out.println(number + " " + "is not prime.");
            return false;
        }
        int counter = 0;
        for (int i = number; i > 0; i--){

            if ((number % (i) ) == 0 && i > 0){

                counter += 1;
            }

        }
        if (counter > 2){
            System.out.println(number + " " + "is not prime.");
            return false;
        }
        else{
            System.out.println(number + " " + "is prime!");
            return true;
        }

    }
//    public static void main(String[] args){
        // create a new scanner to read from the command line
//        java.util.Scanner scanner = new java.util.Scanner(System.in);
//
//        // prompt the user to enter a number
//        System.out.print("Please enter a number: ");
//        // read the next word (up to the first space) and convert it into an int
//        int number = scanner.nextInt();
//        isPrime(number);
////        if (number == 0){
////            System.out.println("Goodbye!");

//
//        }
//        while (number >= 0){
//            if (number == 0) {
//                System.out.println("Goodbye!");
//                break;
//            }
//            else {
//                System.out.print("Please enter a number: ");
//                int num = scanner.nextInt();
//                isPrime(num);
//                scanner.close();
//                continue;
//            }
//        }
        //scanner.close();

        // ALWAYS close your scanner





}
